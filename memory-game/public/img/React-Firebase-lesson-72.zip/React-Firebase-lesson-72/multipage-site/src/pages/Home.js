export default function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatum distinctio temporibus tempora incidunt error ea, libero perspiciatis tempore suscipit beatae officia dolorem et nostrum ducimus veritatis eligendi fugit consectetur non!</p>
    </div>
  )
}
